// var mapp = angular.module('mapp',[]);
// mapp.controller('ctrl',function($scope){
//     var name = $scope("username")
// })